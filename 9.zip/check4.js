
(function(){const saved=localStorage.getItem("drukTheme");const prefers=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;applyTheme(saved|| (prefers?"dark":"light"),false)})();
function applyTheme(theme,save){document.documentElement.setAttribute("data-theme",theme);if(save)localStorage.setItem("drukTheme",theme);const b=$("themeBtn");if(b){b.textContent=theme==="dark"?"☀️":"🌙";b.setAttribute("aria-label",theme==="dark"?"Switch to light mode":"Switch to dark mode");b.title=theme==="dark"?"Switch to light mode":"Switch to dark mode"}}
function toggleTheme(){const next=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";applyTheme(next,true)}
