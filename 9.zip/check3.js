
let chatTimer=null;

async function sendLiveGift(){if(!tok||!current){openAuth();return}const amount=Number(prompt('Gift amount in BTN (10–5000):','100'));if(!Number.isFinite(amount))return;const giftName=prompt('Gift name:','Bhutan Star');if(giftName===null)return;const r=await api('/api/live/gifts/purchase',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({creatorId:current.userId,liveId:current.id,amount,giftName})});const j=await r.json();$('livePayStatus').textContent=r.ok?(j.checkoutUrl?'Opening Bank of Bhutan checkout…':'Gift order created, but BoB checkout is not configured yet.'):(j.error||'Could not create gift order');if(r.ok&&j.checkoutUrl)window.open(j.checkoutUrl,'_blank','noopener');}
async function sendLiveDonation(){if(!tok||!current){openAuth();return}const amount=Number(prompt('Donation amount in BTN (10–100000):','100'));if(!Number.isFinite(amount))return;const r=await api('/api/live/donations/purchase',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({creatorId:current.userId,liveId:current.id,amount})});const j=await r.json();$('livePayStatus').textContent=r.ok?(j.checkoutUrl?'Opening Bank of Bhutan checkout…':'Donation order created, but BoB checkout is not configured yet.'):(j.error||'Could not create donation');if(r.ok&&j.checkoutUrl)window.open(j.checkoutUrl,'_blank','noopener');}
async function loadChat(){
  if(!current)return;
  let room="video:"+current.id;
  let r=await fetch("/api/chat/"+encodeURIComponent(room));
  if(!r.ok)return;
  let arr=await r.json();
  $("chatList").innerHTML=arr.length?arr.map(x=>'<div style="padding:8px 0;border-bottom:1px solid #eef1ef"><div><b>@'+esc(x.username)+'</b> <span class="muted">'+new Date(x.createdAt).toLocaleTimeString()+'</span></div><div>'+esc(x.body)+'</div>'+(me&&((me.id===x.userId)||(me.role==="admin"))?'<button class="ghost" style="padding:5px 8px;margin-top:4px" onclick="deleteChat(\''+x.id+'\')">Delete</button>':'')+'</div>').join(""):"<p class=muted>No messages yet. Start the conversation.</p>";
  let el=$("chatList");el.scrollTop=el.scrollHeight;
}
async function sendChat(){
  if(!tok){openAuth();return}
  let body=$("chatText").value.trim();if(!body)return;
  let r=await api("/api/chat/video:"+encodeURIComponent(current.id),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({body})});
  if(r.ok){$("chatText").value="";$("chatStatus").textContent="";loadChat()}else{let j=await r.json();$("chatStatus").textContent=j.error||"Could not send message"}
}
async function deleteChat(id){let r=await api("/api/chat/"+id,{method:"DELETE"});if(r.ok)loadChat();}
setInterval(()=>{if($("watch")?.classList.contains("show"))loadChat()},5000);
