# Build 77 — DrukTube release hardening

- Fixed the broken inline JavaScript block that prevented the main UI from loading.
- Rebuilt the video watch function with explicit, balanced control flow and error handling.
- Hardened Sign in / Create account: validation, loading state, connection errors, focus, Escape, and backdrop close.
- Fixed hashtag search normalization.
- Fixed signed-out creator-channel browsing.
- Fixed thumbnail preview to use the actual thumbnail input.
- Added release validation for every inline script and server/worker JavaScript files.
- Updated release metadata to 7.3.7 / build 77.
